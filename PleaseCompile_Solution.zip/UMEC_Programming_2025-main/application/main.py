def main():
    print("PLEASE COMPILE!")


if __name__ == "__main__":
    main()