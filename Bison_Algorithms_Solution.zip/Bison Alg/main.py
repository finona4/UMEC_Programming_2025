import csv
import math
import random
from dataclasses import dataclass
from typing import List, Tuple, Optional
import matplotlib.pyplot as plt
import numpy as np
import os

# ---------------------------------------------------------
# DATA STRUCTURES
# ---------------------------------------------------------

# "fire", "police", "medical"
@dataclass
class Station:
    stationId: str
    stype: str         
    x: float
    y: float
    numUnits: int


@dataclass
class Unit:
    unitId: int
    stationId: str
    stype: str
    speed: float
    x: float
    y: float
    availableTime: float = 0.0


@dataclass
class Emergency:
    emergId: int
    t: float
    x: float
    y: float
    emergType: str
    priorityS: float


@dataclass
class Dispatch:
    emergId: int
    unitId: int
    dispatchTime: float
    arrivalTime: float
    timeToDeadlineS: float
    success: bool


# ---------------------------------------------------------
# STARTER CODE (GIVEN)
# ---------------------------------------------------------

def build_initial_stations():
    stations = []
    stations.append(Station('F1','fire', 20,20, 2))
    stations.append(Station('F2','fire',180,20, 2))
    stations.append(Station('P1','police', 50,100, 2))
    stations.append(Station('P2','police',150,120, 2))
    stations.append(Station('H1','medical', 100,30, 2))
    stations.append(Station('H2','medical', 100,170,2))
    return stations

def create_units_from_stations(stations, default_speed=1.0):
    units = []
    uid = 0
    for st in stations:
        for k in range(st.numUnits):
            units.append(Unit(uid, st.stationId, st.stype, default_speed, st.x, st.y))
            uid += 1
    return units

# ---------------------------------------------------------
# Helpers
# ---------------------------------------------------------
# Load emergency events from a CSV file into a list of Emergency objects
def loadEmergs(csvPath):
    emergs = []
    with open(csvPath, newline="") as file:
        reader = csv.DictReader(file)
        for row in reader:
            emerg = Emergency(
                emergId=int(row["id"]),
                t=float(row["t"]),
                x=float(row["x"]),
                y=float(row["y"]),
                emergType=row["etype"].strip(),
                priorityS=float(row["priority_s"])
            )
            emergs.append(emerg)
    emergs.sort(key=lambda emerg: emerg.t)
    return emergs

# Calculate percentage of dispatches that succeeded
def computeSuccessRate(dispatches: List[Dispatch]):
    total = len(dispatches)
    if total == 0:
        return 0.0
    successes = sum(1 for a in dispatches if a.success)
    return successes / total * 100

# Write all dispatch results to a CSV file
def saveDispatchesToCSV(dispatches, output_path):
    with open(output_path, "w", newline="") as f:
        writer = csv.writer(f)

        # header
        writer.writerow([
            "EmergencyID",
            "UnitID",
            "DispatchTime",
            "ArrivalTime",
            "timeToDeadline",
            "Success"
        ])

        # each dispatch row
        for d in dispatches:
            writer.writerow([
                d.emergId,
                d.unitId,
                d.dispatchTime,
                d.arrivalTime,
                d.timeToDeadlineS,
                d.success
            ])

    print("CSV output saved to:", output_path)

# Euclidian rule
def distance(ax, ay, bx, by):
    return math.sqrt((ax - bx)**2 + (ay - by)**2) 


# ---------------------------------------------------------
# DISPATCH LOGIC
# ---------------------------------------------------------
class Simulator:
    #Initialize simulator
    def __init__(self, stations: List[Station], emergs: List[Emergency]):
        self.stations = stations
        self.units = create_units_from_stations(stations)
        self.emergs = emergs
        self.dispatches = []
        self.score = 0

    #Run simulator
    def run(self):
        for emerg in self.emergs:
            self.dispatchEmergency(emerg)

    # Dispatch Emergency(Greedy)
    def dispatchEmergency(self, emerg: Emergency):
        availValUnits = []

        for unit in self.units:
            if unit.stype == emerg.emergType:
                availValUnits.append(unit)

        if len(availValUnits) == 0:
            self.failEmergency(emerg)
            return
        
        bestUnit = None
        bestArrival = float("inf")
        bestDeparture = None

        for unit in availValUnits:
            # Unit can leave only after it's free
            if emerg.t > unit.availableTime:
                departureTime = emerg.t
            else:
                departureTime = unit.availableTime

            # Travel time
            travelTime = distance(unit.x, unit.y, emerg.x, emerg.y)
            arrivalTime = departureTime + travelTime

            # Keep the earliest arrival
            if arrivalTime < bestArrival:
                bestArrival = arrivalTime
                bestDeparture = departureTime
                bestUnit = unit

        # Update the chosen unit's state
        bestUnit.x = emerg.x
        bestUnit.y = emerg.y
        bestUnit.availableTime = bestArrival

        # Success evaluation
        deadline = emerg.t + emerg.priorityS
        success = (bestArrival <= deadline)

        if success:
            self.score += 1
        else:
            self.score -= 1

        timeToDeadline = deadline - bestArrival

        # Record dispatch
        new_dispatch = Dispatch(
            emergId = emerg.emergId,
            unitId = bestUnit.unitId,
            dispatchTime = bestDeparture,
            arrivalTime = bestArrival,
            timeToDeadlineS = timeToDeadline,
            success = success
        )

        self.dispatches.append(new_dispatch)

    # Emergency failed: No available units for deadline
    def failEmergency(self, emerg: Emergency):
        new_dispatch = Dispatch(
            emergId = emerg.emergId,
            unitId = -1,
            dispatchTime = emerg.t,
            arrivalTime = emerg.t,
            timeToDeadlineS = -emerg.priorityS,
            success = False
        )
        self.dispatches.append(new_dispatch)
        self.score = self.score - 1


# ---------------------------------------------------------
# OPTIMIZE STATION LOCATION
# ---------------------------------------------------------
def optimizeLocation(stations: List[Station], emergs: List[Emergency], shift_amount):
    before = []
    for s in stations:
        sationsCopy = Station(s.stationId, s.stype, s.x, s.y, s.numUnits)
        before.append(sationsCopy)

    # Simulate before optimization
    simBefore = Simulator(before, emergs)
    simBefore.run()
    best_score = simBefore.score

    after = [] 
    for s in stations:
        sationsCopy = Station(s.stationId, s.stype, s.x, s.y, s.numUnits)
        after.append(sationsCopy)

    # Try moving each station around
    for s in after:
        # directions
        directions = [
            ("right", shift_amount, 0),
            ("left", -shift_amount, 0),
            ("up", 0, shift_amount),
            ("down", 0, -shift_amount)
        ]

        for direction_name, dx, dy in directions:
            # remember old position
            old_x = s.x
            old_y = s.y

            # compute new position
            new_x = old_x + dx
            new_y = old_y + dy

            # keep the station inside the 0–200 grid
            if new_x < 0:
                new_x = 0
            if new_x > 200:
                new_x = 200
            if new_y < 0:
                new_y = 0
            if new_y > 200:
                new_y = 200

            # apply temporary move
            s.x = new_x
            s.y = new_y

            # Simulate the move
            sim_test = Simulator(after, emergs)
            sim_test.run()
            score = sim_test.score

            # accept move only if score matches or improves best score
            if score >= best_score:
                best_score = score
                print(s.stationId, "moved", direction_name, "to",
                      new_x, new_y, "score =", score)
            else:
                s.x = old_x  # revert bad move
                s.y = old_y

    return before, after  # return original and optimized layouts


# ---------------------------------------------------------
# VISUALIZATION (BEFORE & AFTER)
# ---------------------------------------------------------

def plotBeforeAfter(beforeStations, afterStations, emergs):

    fig, axs = plt.subplots(1, 2, figsize=(15, 7))

    xs_before = []
    ys_before = []
    for e in emergs:
        xs_before.append(e.x)
        ys_before.append(e.y)

    axs[0].scatter(xs_before, ys_before, s=10, c="gray", alpha=0.3)

    for st in beforeStations:
        if st.stype == "fire":
            color = "red"
        elif st.stype == "police":
            color = "blue"
        else:
            color = "green"

        axs[0].scatter(st.x, st.y, s=160, marker="s", c=color, edgecolor="black")
        axs[0].text(st.x + 2, st.y + 2, st.stationId)

    axs[0].set_title("Before Optimized Locations")
    axs[0].set_xlim(0, 200)
    axs[0].set_ylim(0, 200)
    axs[0].grid(True)

    xs_after = []
    ys_after = []
    for e in emergs:
        xs_after.append(e.x)
        ys_after.append(e.y)

    axs[1].scatter(xs_after, ys_after, s=10, c="gray", alpha=0.3)

    for st in afterStations:
        if st.stype == "fire":
            color = "red"
        elif st.stype == "police":
            color = "blue"
        else:
            color = "green"

        axs[1].scatter(st.x, st.y, s=160, marker="s", c=color, edgecolor="black")
        axs[1].text(st.x + 2, st.y + 2, st.stationId)

    axs[1].set_title("After Layout")
    axs[1].set_xlim(0, 200)
    axs[1].set_ylim(0, 200)
    axs[1].grid(True)

    plt.show()


# ---------------------------------------------------------
# MAIN
# ---------------------------------------------------------

def main():
    folder_path = os.path.dirname(os.path.abspath(__file__))
    csv_path = os.path.join(folder_path, "emergency_events.csv")

    print("Loading emergency events from:", csv_path)

    # Load emergencies and initial stations
    emergs = loadEmergs(csv_path)
    stations_start = build_initial_stations()

    # Run simulation on original layout
    sim_before = Simulator(stations_start, emergs)
    sim_before.run()

    print("=== ORIGINAL LAYOUT ===")
    print("Score:", sim_before.score)

    rate_before = computeSuccessRate(sim_before.dispatches)
    print("Success Rate:", f"{rate_before:.2f}%")

    # Run optimization
    print("\nRunning Location optimization...")
    stations_before, stations_after = optimizeLocation(
        stations_start,
        emergs,
        shift_amount=50
    )

    # Run simulation on optimized stations
    sim_after = Simulator(stations_after, emergs)
    sim_after.run()

    print("\n=== OPTIMIZED LAYOUT ===")
    print("Score:", sim_after.score)

    rate_after = computeSuccessRate(sim_after.dispatches)
    print("Success Rate:", f"{rate_after:.2f}%")

    # Save dispatch CSV
    output_path = os.path.join(folder_path, "dispatch_results.csv")

    print("\nSaving CSV to:", output_path)
    saveDispatchesToCSV(sim_after.dispatches, output_path)

    # Now plot
    print("\nPlotting before/after maps...")
    plotBeforeAfter(stations_before, stations_after, emergs)

if __name__ == "__main__":
    main()