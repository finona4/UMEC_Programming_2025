#include <bits/stdc++.h>

using namespace std;


struct Emergency {
    long double t;
    long double x, y;
    string etype;
    long double priority;
};

struct Station {
    int x, y;
    string type;
    multiset<long double> dispatchedTime;
};

bool customSort(Emergency& e1, Emergency& e2){
    return e1.t < e2.t;
}

vector<Emergency> readEmergencies(const string& filename) {
    vector<Emergency> emergencies;
    ifstream file(filename);
    string line;
    getline(file, line);

    while (getline(file, line)) {
        stringstream ss(line);
        Emergency e;
        string temp;
        getline(ss, temp, ','); e.t = stold(temp);
        getline(ss, temp, ','); e.x = stold(temp);
        getline(ss, temp, ','); e.y = stold(temp);
        getline(ss, temp, ','); e.etype = temp;
        getline(ss, temp, ','); e.priority = stold(temp);
        getline(ss, temp, ','); // Don't need ID
        emergencies.push_back(e);
    }

    sort(emergencies.begin(), emergencies.end(), customSort);

    return emergencies;
}


vector<Station> stations;

int findNearestStation(const Emergency& e, long double currentTime) {
    long double minDistance = 1e100;
    int idx = -1;
    int i = 0;

    for (auto& station : stations) {
        bool canHandle = false;

        if (station.type == "fire" && (e.etype == "fire" || e.etype == "medical")) {
            canHandle = true;
        }
        else if (station.type == "medical" && (e.etype == "medical" || e.etype == "police")) {
            canHandle = true;
        }
        else if (station.type == "police" && e.etype == "police") {
            canHandle = true;
        }

        if (e.t - *station.dispatchedTime.begin() < 0){
            canHandle = false;
        }


        if (canHandle) {
            double distance = abs(e.x - station.x) + abs(e.y - station.y);
            if (distance < minDistance) {
                minDistance = distance;
                idx = i;
            }
        }
        i++;
    }
    return idx;
}

void handleEmergencies(const vector<Emergency>& emergencies) {
    long double totalScore = 0;
    int missed = 0;

    int fires = 0, medicals = 0, crime = 0;

    for (auto& e : emergencies){
        int idx = findNearestStation(e, e.t);
        Station& station = stations[idx];


        long double responseTime = abs(station.x - e.x) + abs(station.y - e.y);

        long double remainingTime = e.priority - responseTime;

        if (remainingTime >= 0 && idx != -1) {
            totalScore += remainingTime / 60;

            station.dispatchedTime.erase(station.dispatchedTime.begin());

            station.dispatchedTime.insert(e.t + responseTime * 2);
        } else {
            totalScore -= 2;

            missed++;

            if (e.etype == "police")
                crime++;
            if (e.etype == "medical")
                medicals++;
            if (e.etype == "fire")
                fires++;
        }
    }


    cout << "Final score: " << totalScore << "\n";

    cout << "Missed a total of " << missed << " emergencies, corresponds to a success rate of " << ((long double) 1 - (long double) missed / emergencies.size()) * 100;

    cout << "\nTotal number of missed Fires: " << fires << ", Medicals: " << medicals << ", Crimes: " << crime;
}

int main() {
    vector<Emergency> emergencies = readEmergencies("emergency_events.csv");

    stations = {
        {100, 100, "police", {0}},

        {50, 50, "medical", {0}},
        {150, 50, "medical", {0}},
        {50, 150, "medical", {0}},
        {150, 150, "medical", {0}},

        {30, 30, "fire", {0}},
        {100, 30, "fire", {0}},
        {170, 30, "fire", {0}},
        {30, 100, "fire", {0}},
        {100, 100, "fire", {0}},
        {170, 100, "fire", {0}},
        {30, 170, "fire", {0}},
        {100, 170, "fire", {0}},
        {170, 170, "fire", {0}},
    };

    handleEmergencies(emergencies);

    return 0;
}
